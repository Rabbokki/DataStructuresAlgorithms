package vendingMachineV3.view;

public interface AdminViewInterface {
    void mainAdminView();
    void salesManagerView();
    void productManagerView();
    void userManagerView();
}
